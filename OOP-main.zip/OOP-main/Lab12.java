import java.util.*;
public class Lab12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int stamp ;
        System.out.println("Total Price : " + (stamp = sc.nextInt()));
        stamp = (int)stamp / 50;
        System.out.println("You got " + stamp + " stamp(s)");
        
    }
}
